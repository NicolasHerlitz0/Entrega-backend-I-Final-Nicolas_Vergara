#  E-commerce Backend - Entrega 1 

##  Descripción
Servidor backend para gestión de productos y carritos de compra.

##  Instalación
bash
npm install
node src/app.js